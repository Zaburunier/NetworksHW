﻿using System;
using System.Timers;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace NetworksHW {
    class ErrorVector {

        // Текущий вектор ошибки
        private int[] vector;
        // Для проверки существования вектора данной кратности в классе
        private bool initialized;
        // Текущее значение кратности
        private int errorRate;
        // Храним индексы единиц
        private List<int> ones;
        // Файл, в который будем записывать всю информацию (в консоль не помещается :) )
        private FileStream infoFile;
        public ErrorVector(FileStream file) {
            vector = new int[15] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            initialized = false;
            errorRate = 0;
            ones = new List<int>();
            infoFile = file;
        }

        public void HammingProcessing() {
            Stopwatch timer = new Stopwatch();
            timer.Start();
            foreach (int[] v in this.GetVectors()) {
                string stringToFile = "Для вектора ошибки \"" + this.ToString() + "\" :\n";
                byte[] currentVectorInfo = new UTF8Encoding().GetBytes(stringToFile);
                infoFile.Write(currentVectorInfo, 0, currentVectorInfo.Length);
            }
            byte[] timeInfo = new UTF8Encoding().GetBytes(("Время выполнения обработки через смещения: " + Convert.ToString(timer.ElapsedMilliseconds)));
            infoFile.Write(timeInfo, 0, timeInfo.Length);
        }

        public new string ToString() {
            string s = "";
            for (int i = vector.Length - 1; i >= 0; i = i - 1) {
                s = s + vector[i].ToString();
            }
            return s;
        }

        /*public static bool operator ==(ErrorVector errVec, string str) {
            if (str.Length != errVec.vector.Length) return false;
            
            for (int i = 0; i < errVec.vector.Length; i = i + 1) {
                if (errVec.vector[i] != Convert.ToInt32(str[i]) - 48) return false;
            }

            return true;
        }

        public static bool operator !=(ErrorVector errVec, string str) {
            if (errVec == str) return false;
            return true;
        }*/
        /*public IEnumerable GetVectors() {
            while (true) {
                // Если мы ещё не создали вектор для текущей кратности
                if (!initialized) {
                    if (errorRate == 15) {
                        yield break;
                    } else {
                        CreateFirstVector();
                    }
                }
                // Итерируемся, пока не дойдём до последнего
                yield return vector;
                if (!CheckTheLatter()) {
                    MoveToNextVector();
                }
            }

        }*/

        public IEnumerable GetVectors() {
            while (true) {
                // Если мы ещё не создали вектор для текущей кратности
                if (!initialized) {
                    if (errorRate == 15) {
                        yield break;
                    } else {
                        CreateFirstVector();
                    }
                }
                // Итерируемся, пока не дойдём до последнего
                yield return vector;
                if (!CheckTheLatter()) {
                    MoveToNextVector();
                }
            }

        }

        // Проверяем, является ли вектор ошибки последним для данной кратности
        private bool CheckTheLatter() {
            /* Последним вектором считается тот, 
             * который имеет в n старших разрядах вектора единицы, 
             * а во всех остальных - нули (n - кратность ошибки).*/

            int currentIndex = vector.Length - 1;
            while (currentIndex >= vector.Length - errorRate) {
                if (vector[currentIndex] == 0) {
                    return false;
                }
                currentIndex = currentIndex - 1;
            }
            initialized = false;
            ones.Clear();
            return true;
        }

        // Создаём первый вектор для текущего значения кратности
        private void CreateFirstVector() {
            /* Первым вектором считается тот,
             * который имеет в n младших разрядах единицы, 
             * а во всех остальных - нули (n - кратность ошибки)
             */

            errorRate = errorRate + 1;
            initialized = true;
            // Заносим начальный вектор
            for (int i = 0; i < vector.Length; i = i + 1) {
                if (i < errorRate) {
                    ones.Add(i);
                    vector[i] = 1;
                } else {
                    vector[i] = 0;
                }
            }
        }

        // Переход к следующему вектору данной кратности
        private void MoveToNextVector() {
            if (ones[errorRate - 1] != vector.Length - 1) {
                // Если доступна, то просто сдвигаем её
                MoveOneToNext(errorRate - 1);
            } else {
                // Если же недоступна, то необходимо перегруппировать единицы в векторе
                // Определяем первый доступный для сдвига уровень
                int currentLevel = errorRate - 1;
                while (currentLevel > 0) {
                    currentLevel = currentLevel - 1;
                    if (vector[ones[currentLevel] + 1] == 0 && vector[ones[currentLevel]] == 1) { // Второе условие добавлено исключительно для читаемости кода
                        break;
                    }
                }

                MoveOnesToNextLayout(currentLevel);
            }

        }

        // Сдвиг единички на одну позицию
        private void MoveOneToNext(int oneLevel) {
            vector[ones[oneLevel]] = 0;
            vector[ones[oneLevel] + 1] = 1;
            ones[oneLevel] = ones[oneLevel] + 1;
        }

        // Установка всех упёршихся единичек в новое положение для продолжения обхода
        private void MoveOnesToNextLayout(int oneLevel) {
            // Сдвинем предыдущую единицу вперёд
            vector[ones[oneLevel]] = 0;
            vector[ones[oneLevel] + 1] = 1;
            ones[oneLevel] = ones[oneLevel] + 1;

            // После сдвига пред. единицы начинаем возвращать по цепочке все упёршиеся
            int currentIndex = ones[oneLevel] + 1,
                currentLevel = oneLevel + 1;
            while (currentLevel < errorRate) {
                vector[ones[currentLevel]] = 0;
                vector[currentIndex] = 1;
                ones[currentLevel] = currentIndex;
                currentLevel = currentLevel + 1;
                currentIndex = currentIndex + 1;
            }
        }

    }
}
