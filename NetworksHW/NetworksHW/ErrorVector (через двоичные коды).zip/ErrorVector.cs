﻿using System;
using System.Timers;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace NetworksHW {
    class ErrorVector {

        // Текущий вектор ошибки
        private BitArray vector;
        short counter;
        // Для проверки существования вектора данной кратности в классе
        private bool initialized;
        // Текущее значение кратности
        private int errorRate;
        // Храним индексы единиц
        private List<int> ones;
        // Файл, в который будем записывать всю информацию (в консоль не помещается :) )
        private FileStream infoFile;
        public ErrorVector(FileStream file) {
            vector = new BitArray(15, false);
            counter = 0;
            initialized = false;
            errorRate = 0;
            ones = new List<int>();
            infoFile = file;
        }

        public void HammingProcessing() {
            Stopwatch timer = new Stopwatch();
            timer.Start();
            foreach (BitArray v in this.GetVectors()) {
                string stringToFile = "Для вектора ошибки \"" + this.ToString() + "\" :\n";
                byte[] currentVectorInfo = new UTF8Encoding().GetBytes(stringToFile);
                infoFile.Write(currentVectorInfo, 0, currentVectorInfo.Length);
            }
            byte[] timeInfo = new UTF8Encoding().GetBytes(("Время выполнения обработки через смещения: " + Convert.ToString(timer.ElapsedMilliseconds)));
            infoFile.Write(timeInfo, 0, timeInfo.Length);
        }

        public new string ToString() {
            string s = "";
            for (int i = vector.Length - 1; i >= 0; i = i - 1) {
                s = s + (vector[i] == false ? '0' : '1');
            }
            return s;
        }

        /*public static bool operator ==(ErrorVector errVec, string str) {
            if (str.Length != errVec.vector.Length) return false;
            
            for (int i = 0; i < errVec.vector.Length; i = i + 1) {
                if (errVec.vector[i] != Convert.ToInt32(str[i]) - 48) return false;
            }

            return true;
        }

        public static bool operator !=(ErrorVector errVec, string str) {
            if (errVec == str) return false;
            return true;
        }*/
        /*public IEnumerable GetVectors() {
            while (true) {
                // Если мы ещё не создали вектор для текущей кратности
                if (!initialized) {
                    if (errorRate == 15) {
                        yield break;
                    } else {
                        CreateFirstVector();
                    }
                }
                // Итерируемся, пока не дойдём до последнего
                yield return vector;
                if (!CheckTheLatter()) {
                    MoveToNextVector();
                }
            }

        }*/

        public IEnumerable GetVectors() {
            while (counter < Int16.MaxValue) {
                counter++;
                string binaryVectorStr = Convert.ToString(counter, 2);
                for (int i = vector.Length - 1; i >= binaryVectorStr.Length; i = i - 1) {
                    vector[i] = false;
                }
                for (int i = binaryVectorStr.Length - 1; i >= 0; i = i - 1) {
                    vector[i] = Convert.ToInt32(binaryVectorStr[binaryVectorStr.Length - 1 - i]) == 48 ? false : true;
                }
                yield return vector;

            }
        }
        
    }
}
